
This is a simple vehile detection project using Computer Vision

Here I used background subtractions methods of OpenCV Library of Python and some morphological transformation for accuracy.
But this is for only static cameras. 

At the corner of the video you can see the count of the vehicles which gets recorded
when they cross a predefined limit. For the calculation of the object coordinates and object ids I defined a class called vehicles.py

For running it, just download all files and run the main.py
Thank you.
